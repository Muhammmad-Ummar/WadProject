const authorize=(role)=>{
    return (req,res,next)=>{
        if(role!=req.data.role)
            return res.send(`Access Denied!only ${role} allowed to acces`);
        next();
    }
}
module.exports={authorize}