document.getElementById('bookNow').addEventListener('click', function (event) {
    event.preventDefault(); // Prevent form submission
  
    const bookingDate = document.getElementById('bookingDate').value;
    const timeSlot = document.getElementById('timeSlot').value;
    const serviceType = document.getElementById('serviceType').value;
  
    let price = '';
    if (serviceType === 'washing') {
      price = '200 per clothe';
    } else if (serviceType === 'drying') {
      price = '90 per clothe';
    } else if (serviceType === 'ironing') {
      price = '40 per clothe';
    }
  
    // Update modal content
    document.getElementById('confirmDate').textContent = bookingDate;
    document.getElementById('confirmTimeSlot').textContent = timeSlot;
    document.getElementById('confirmServiceType').textContent = serviceType;
    document.getElementById('confirmPrice').textContent = price;
  
    // Show the modal
    const confirmOrderModal = new bootstrap.Modal(document.getElementById('confirmOrderModal'));
    confirmOrderModal.show();
  });