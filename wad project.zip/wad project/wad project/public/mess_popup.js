const menuData = {
    monday: ['Eggs', 'Pancakes', 'Fruit Juice'],
    tuesday: ['Vegetable Sandwich', 'French Toast', 'Tea'],
    wednesday: ['Omelette', 'Cereal', 'Coffee'],
    thursday: ['Paratha', 'Yogurt', 'Tea'],
    friday: ['Fried Rice', 'Spring Rolls', 'Juice'],
    saturday: ['Poha', 'Pudding', 'Coffee'],
    sunday: ['Chole Bhature', 'Lassi', 'Sweets']
  };
  // Function to update menu and price based on selected options
  function updateMenuAndPrice() {
    const selectedDay = document.getElementById('weekDay').value;
    const selectedDayName = document.getElementById('selectedDay');
    const selectedPackage = document.getElementById('packageSelect').value;
    const menuList = document.getElementById('menuList');
    const priceSection = document.getElementById('priceSection');
    let day=selectedDay.charAt(0).toUpperCase()+selectedDay.slice(1);
    selectedDayName.textContent=day;
    // Update the menu for the selected day
    menuList.innerHTML = ''; // Clear the existing menu items
    menuData[selectedDay].forEach(item => {
      const listItem = document.createElement('li');
      listItem.textContent = item;
      menuList.appendChild(listItem);
    });

    // Update price based on selected package
    let price = 0;
    if (selectedPackage === 'daily') {
      price = 300;
    } else if (selectedPackage === 'weekly') {
      price = 1800;
    } else if (selectedPackage === 'monthly') {
      price = 6000;
    }
    priceSection.textContent = `Price: ${price} PKR (${selectedPackage.charAt(0).toUpperCase() + selectedPackage.slice(1)})`;
  }

  // Handle form submission and show modal
  function handleBooking(event) {
    event.preventDefault(); // Prevent form submission

    const bookingDate = document.getElementById('bookingDate').value;
    const selectedDay = document.getElementById('weekDay').value;
    const selectedPackage = document.getElementById('packageSelect').value;
    
    let price = 0;
    if (selectedPackage === 'daily') {
      price = 300;
    } else if (selectedPackage === 'weekly') {
      price = 1800;
    } else if (selectedPackage === 'monthly') {
      price = 6000;
    }

    // Show the booking details in the modal
    document.getElementById('confirmBookingDate').textContent = bookingDate;
    document.getElementById('confirmBookingDay').textContent = selectedDay;
    document.getElementById('confirmBookingPackage').textContent = selectedPackage;
    document.getElementById('confirmBookingPrice').textContent = `${price} PKR (${selectedPackage})`;

    // Show the confirmation modal
    const confirmBookingModal = new bootstrap.Modal(document.getElementById('confirmBookingModal'));
    confirmBookingModal.show();
  }

  // Event listeners
  document.getElementById('weekDay').addEventListener('change', updateMenuAndPrice);
  document.getElementById('packageSelect').addEventListener('change', updateMenuAndPrice);
  document.getElementById('bookNow').addEventListener('click', handleBooking);

  // Initialize the page with default selections
  updateMenuAndPrice();