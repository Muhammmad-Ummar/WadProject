document.getElementById('bookNow').addEventListener('click', function (event) {
    event.preventDefault(); // Prevent form submission

    const bookingDate = document.getElementById('bookingDate').value;
    const roomType = document.getElementById('roomType').value;
    const additionalFeature = document.getElementById('additionalFeature').value;

    const basePrices = {
      "two-seater": 1200,
      "three-seater": 1000
    };

    const featurePrices = {
      "ac": 200,
      "wifi": 150,
      "balcony": 100,
      "none": 0
    };

    // Calculate total price
    let price = basePrices[roomType] + featurePrices[additionalFeature];

    // Update modal content
    document.getElementById('confirmDate').textContent = bookingDate;
    document.getElementById('confirmRoomType').textContent = roomType;
    document.getElementById('confirmAdditionalFeatures').textContent = additionalFeature;
    document.getElementById('confirmPrice').textContent = `Price: ${price}`;

    // Show the modal
    const confirmOrderModal = new bootstrap.Modal(document.getElementById('confirmOrderModal'));
    confirmOrderModal.show();
  });