document.querySelector('#serviceType').addEventListener('change', function() {
    var selectedPackage = this.value;
    var priceSection = document.getElementById('laundry_price');
  
    if (selectedPackage === 'washing') {
      priceSection.textContent = 'Price: 200 per clothe';
    } else if (selectedPackage === 'drying') {
      priceSection.textContent = 'Price: 90 per clothe';
    } else if (selectedPackage === 'ironing') {
      priceSection.textContent = 'Price: 40 per clothe';
    }
  });