const express = require('express');
const path = require('path');
const app = express();
const cookie=require("cookie-parser")
const {router}=require("./routes/userAuthentication")
const {router1}=require("./routes/userAuthorize")
const port=81;
//------------------------
app.set("view engine","ejs")
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({extended:false}))
app.use(express.json())
app.use(cookie())
app.use(express.static(path.join(__dirname, 'public')));
require("dotenv").config();
//---------------------------
app.use("/",router);
app.use("/user",router1);

const host='localhost';
app.listen(port,host,()=>{
  console.log(`server running at http://${host}:${port}/login`)
})














// app.use(express.static(path.join(__dirname, 'public')));
// app.use(express.urlencoded({ extended: false }))
// // Set EJS as the templating engine
// app.set('view engine', 'ejs');
// const authenticate = require("./routes/authenticate")
// // Define a route
// app.use('/', authenticate)
// app.get('/', (req, res) => {
//   res.render('index'); // This will render index.ejs
// });
// app.get('/admin_profile', (req, res) => {
//   res.render('admin_Profile');
// });
// app.get('/admin_room', (req, res) => {
//   res.render('admin_room');
// });
// app.get('/admin', (req, res) => {
//   res.render('admin');
// });
// app.get('/mess_data', (req, res) => {
//   res.render('mess_data');
// });
// app.get('/admin_feedbacks', (req, res) => {
//   res.render('admin_feedbacks');
// });
// app.get('/hostel_register', (req, res) => {
//   res.render('hostel_register');
// });
// app.get('/mess_booking', (req, res) => {
//   res.render('mess_booking'); // This will render index.ejs
// });
// app.get('/laundry_data', (req, res) => {
//   res.render('laundry_data'); // This will render index.ejs
// });
// app.get('/laundry_booking', (req, res) => {
//   res.render('laundry_booking'); // This will render index.ejs
// });
// app.get('/hostel_admin', (req, res) => {
//   res.render('hostelAdmin'); // This will render index.ejs
// });
// app.get('/Room_data', (req, res) => {
//   res.render('Room_data');
// });
// app.get('/book_Room', (req, res) => {
//   res.render('room_booking');
// });
// app.get('/profile', (req, res) => {
//   res.render('profile');
// });
// app.get('/registered_services', (req, res) => {
//   res.render('registered_service');
// });
// app.get('/room_feedback', (req, res) => {
//   res.render('room_feedback');
// });
// Start the server
