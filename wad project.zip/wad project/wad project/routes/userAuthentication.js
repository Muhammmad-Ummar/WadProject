const express=require("express")
const {handleSignin,viewSignin,viewLogin,handleLogin,handleLogout}=require("../controller/userAuthenticate")
const router=express.Router();
router.get("/signup",viewSignin)
router.post("/signup",handleSignin)
router.get("/login",viewLogin)
router.post("/login",handleLogin)
router.post("/logout",handleLogout)
module.exports={router}