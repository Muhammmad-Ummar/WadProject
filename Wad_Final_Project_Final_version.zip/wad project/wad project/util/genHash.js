const bcrypt=require("bcrypt");
const passport = require("passport");
const hashPass=async(password)=>{
 let hash=await bcrypt.hash(password,10);
 return hash;
}
const comparePassword=async(password,hashPassword)=>{
return await bcrypt.compare(password,hashPassword)
}
module.exports={hashPass,comparePassword}