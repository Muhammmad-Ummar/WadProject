const dbConnect=require("../config/db-connect")

dbConnect.db;
const {hashPass}=require("../util/genHash")
const {comparePassword}=require("../util/genHash")
const {User}=require("../models/userModel")

const jwt=require("jsonwebtoken");
const viewSignin=(req,res,next)=>{
return res.render("signup",{error:null,success:null});
}
const handleSignin=async(req,res,next)=>{
    const {userName,userEmail,userPassword,role}=req.body;
    try{
        if(!userName||!userEmail||!userPassword||!role)
            return res.render("signup",{error:"kindly enter all data",success:null});
       const hashed=await hashPass(userPassword)
        let user=new User({
            userName,userEmail,userPassword:hashed,role
        })
        await user.save()
        return res.render("signup",{error:null,success:"successfully registered"});
    }catch(err){
       if(err.code==11000)  return res.render("signup",{error:"User already exists",success:null});
       console.log(err)
        return res.status(500).send("internal server error")
    }

}
const viewLogin=(req,res,next)=>{
    return res.render("login",{error:null});
    }

const handleLogin=async(req,res,next)=>{
        const {userEmail,userPassword}=req.body;
        try{
            if(!userEmail||!userPassword)
                return res.render("login",{error:"kindly enter all data"});
             let user=await User.findOne({userEmail})
             if(!user)return res.render("login",{error:"User doesnot registered"});
           const check=await comparePassword(userPassword,user.userPassword)//(enteredPass,hashedPass)
           if(!check)return res.render("login",{error:"Kindly enter correct password"});
             let encData=jwt.sign({userEmail,role:user.role,id:user._id},process.env.TOKEN_PASSWORD,{expiresIn:"1h"})
             res.cookie("data",encData)
            return res.redirect("/user/profile");
        }catch(err){
           console.log(err)
            return res.status(500).send("internal server error")
        }
    
    }
const handleLogout=(req,res)=>{
    res.clearCookie("data");
    res.redirect("/login")
}
module.exports={viewSignin,handleSignin,viewLogin,handleLogin,handleLogout}

