const {User}=require("../models/userModel")
const Room=require("../models/roomModel")
const {Feedback}=require("../models/feedback")
const mongoose=require("mongoose");
const Mess=require('../models/Mess')
let authorizeController=async(req,res)=>{
    try{
        let data=await User.findOne({_id:req.data.id})
        if(req.data.role=="customer"){
            let rooms=await Room.find({})
            return res.render("index",{data,rooms})
        }
            if(req.data.role=="hostelAdmin")
            return res.render("hostelAdmin",{data})
    }catch(err){
        console.log(err)
        return res.send("internal server error")
    }
}
let viewHostelRegister=async(req,res)=>{
    let data=await User.findOne({_id:req.data.id})
   res.render("hostel_register",{data})
}
let viewHostelRooms=async(req,res)=>{
    let data=await User.findOne({_id:req.data.id})
    let rooms=await Room.find({ hostelAdminId: req.data.id })
    
    let users = [];

    for (const room of rooms) {
        console.log(room.roomName,room.customersId)
      if (room.customersId && room.customersId.length) {//checking if some user registered or not
        for (const customer of room.customersId) {
         let details=await User.findOne({ _id: customer._id })//for getting name of user enrolled
          users.push({
            id:details._id,
            name: details.userName,
            roomName: room.roomName,
            roomPrice: room.roomPrice
          });
        };
      }
    };

     res.render("admin_room",{data,rooms,users})
}
let createHostelRooms=async(req,res)=>{
    let {roomName,roomType,roomPrice,roomDescription}=req.body
    try{
         let rooms=new Room({roomName,roomType,roomPrice,roomDescription,customersId:[],hostelAdminId:req.data.id})
         await rooms.save()
        res.redirect("/user/admin_room")
    }
    catch(err){
        console.log(err)
        res.status(500).send("internal server error!")
    }
   
}
let deleteHostelRooms=async(req,res)=>{
    try{
        await Room.findOneAndDelete({_id:req.params.id})
        res.redirect("/user/admin_room")
    }
    catch(err){
        console.log(err)
        res.status(500).send("internal server error!")
    }
   
}

let viewRoomBooking=async(req,res)=>{
   try{
    let rooms=await Room.find({})
    let data=await User.findOne({_id:req.data.id})
      res.render("Room_data",{data,rooms})
   }catch(err){
    console.log(err)
    res.status(500).send("internal server error!")
   }
   
}
let handleRoomBooking=async(req,res)=>{
    try{
     let rooms=await Room.findOneAndUpdate({_id:req.params.id},{$push:{customersId:req.data.id}},{new:true})
     console.log(rooms)
     res.send("successfully Booked")
    }catch(err){
     console.log(err)
     res.status(500).send("internal server error!")
    }
    
 }
 
 let updateHostelRooms=async(req,res)=>{
    let{roomName,roomDescription,roomPrice}=req.body
    try{
       await Room.findOneAndUpdate({_id:req.params.id},{roomName,roomDescription,roomPrice},{new:true})
     res.redirect("/user/admin_room")
    }catch(err){
     console.log(err)
     res.status(500).send("internal server error!")
    }
}
let removeRoomMemeber=async(req,res)=>{
    try{
        const room = await Room.findOne({ customersId: req.params.id });
          // Remove only one instance of the customer ID
          const index = room.customersId.indexOf(req.params.id);
            room.customersId.splice(index, 1); // Remove only one occurrence
            await room.save(); // Save the updated document
     res.redirect("/user/admin_room")
    }catch(err){
     console.log(err)
     res.status(500).send("internal server error!")
    }
 }
let viewRoomFeedback=async(req,res)=>{
    try{
       let data=await User.findOne({_id:req.data.id})
       const id = new mongoose.Types.ObjectId(req.data.id);
       const room = await Room.findOne({ customersId: id });
       res.render("room_feedback",{data,room})
    }catch(err){
     console.log(err)
     res.status(500).send("internal server error!")
    }
    
 }
 let giveRoomFeedback=async(req,res)=>{
   let {roomQuality,foodQuality,cleanliness, overallExperience}=req.body
    try{
        const id = new mongoose.Types.ObjectId(req.data.id);
        const room = await Room.findOne({ customersId: id});
       let feedback= new Feedback({roomQuality,foodQuality,cleanliness, overallExperience,customerId:req.data.id,roomId:room._id,hostelAdminId:room.hostelAdminId})
       await feedback.save()
       res.redirect("/user/room_feedback")
    }catch(err){
     console.log(err)
     res.status(500).send("internal server error!")
    }
    
 }

 let  viewResidentsFeedback=async(req,res)=>{
    try{
       let data=await User.findOne({_id:req.data.id})
       let feedbacks=await Feedback.find({hostelAdminId:req.data.id})//it contains array of ibjects contain CID
       res.render("admin_feedbacks",{data,feedbacks})
    }catch(err){
     console.log(err)
     res.status(500).send("internal server error!")
    }
    
 }
 const viewUsers = async (req, res, next) => {
    try {
        const users = await User.find();  // Fetch all users
        return res.render("admin_dashboard", { users }); // Send to EJS
    } catch (err) {
        console.error(err);
        return res.status(500).send("Internal server error");
    }
};

const viewMessDetail = async (req, res, next) => {
    try {
        const messDetails = await Mess.find();  // Corrected variable name
        return res.render("view_mess", { messDetails, data: req.data }); // Ensure `data` is passed
    } catch (err) {
        console.error(err);
        return res.status(500).send("Internal Server Error");
    }
};

const viewMessbooking = async (req, res, next) => {
    try {
        const users = await User.find();
        const messDetails = await Mess.find(); 
        const data = req.user ? { userName: req.user.name } : { userName: "Guest" };
        return res.render("mess_data", { users, messDetails, data });
    } catch (err) {
        console.error(err);
        return res.status(500).send("Internal server error");
    }
};



const viewaddmess = async (req, res, next) => {
    try {
        const users = await User.find();
        const messDetails = await Mess.find(); // Fetch mess details
        const data = req.user ? { userName: req.user.name } : { userName: "Guest" };
        return res.render("admin_mess", { users, messDetails, data });
    } catch (err) {
        console.error(err);
        return res.status(500).send("Internal server error");
    }
};
////////////////////////////////////////////////////////////////////////////////////
                  //Admin add mess
/////////////////////////////////////////////////////////////////////////////////

const addMessDetails = async (req, res) => {
    try {
        const { bookingDate, weekDay, packageType, menu, price } = req.body;
        
       
        const newMess = new Mess({
            bookingDate,
            weekDay,
            packageType,
            menu: menu.split(",").map(item => item.trim()), 
            price,
            createdBy: req.data.id 
        });

        await newMess.save();
        res.status(201).json({ message: "Mess details added successfully", mess: newMess });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to add mess details" });
    }
};


const viewMessDetails = async (req, res) => {
    try {
        const messDetails = await Mess.find();
        res.status(200).json(messDetails);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to fetch mess details" });
    }
};

const bookMessMeal = async (req, res) => {
    try {
        const { messId } = req.params;
        const mess = await Mess.findById(messId);

        if (!mess) {
            return res.status(404).json({ error: "Mess details not found" });
        }

        res.status(200).json({ message: "Mess meal booked successfully", mess });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to book mess meal" });
    }
};


const viewMessAdmin = async (req, res) => {
    try {
        const messDetails = await Mess.find();
        const bookedMessDetails = await Booking.find().populate("user").populate("mess");

        console.log("bookedMessDetails:", bookedMessDetails); // Debugging line

        return res.render("admin_mess", { 
            messDetails: messDetails || [], 
            bookedMessDetails: bookedMessDetails || [] 
        });
    } catch (err) {
        console.error("Error fetching mess details:", err);
        return res.status(500).send("Internal Server Error");
    }
};


module.exports = { viewUsers };

module.exports={authorizeController,viewHostelRegister,viewUsers,viewMessAdmin,
    viewHostelRooms,createHostelRooms,deleteHostelRooms,viewMessbooking,
    viewRoomBooking,handleRoomBooking,updateHostelRooms,
    addMessDetails, viewMessDetails, bookMessMeal,
    addMessDetails, 
    viewMessDetails, 
    viewMessDetail,
    bookMessMeal, 
    viewaddmess,
    removeRoomMemeber,viewRoomFeedback,giveRoomFeedback, viewResidentsFeedback}