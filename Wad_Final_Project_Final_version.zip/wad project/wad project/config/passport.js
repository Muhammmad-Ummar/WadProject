const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const userModel = require('../models/userModel');

passport.use('local', new LocalStrategy(
  {
    usernameField: 'userEmail',  // If you're using 'userEmail' in your form input
    passwordField: 'userPassword'  // If you're using 'userPassword' in your form input
  },
  async (userEmail, password, done) => {
    try {
      const user = await userModel.findOne({ userEmail });
      if (!user) {
        return done(null, false, { message: 'Incorrect email or password.' });
      }

      // Assuming user.comparePasswords is a method on your user model for comparing passwords
      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return done(null, false, { message: 'Incorrect email or password.' });
      }

      return done(null, user);  // Successful login
    } catch (err) {
      return done(err);  // Handle errors during query or password comparison
    }
  }
));

passport.serializeUser((user, done) => {
  done(null, user.id);  // Store user ID in session
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await userModel.findById(id);
    done(null, user);  // Retrieve the full user object
  } catch (err) {
    done(err);  // Handle error during deserialization
  }
});

module.exports = passport;
