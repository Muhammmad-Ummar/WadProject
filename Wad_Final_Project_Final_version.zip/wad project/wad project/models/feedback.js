const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema({
  name: {
    type: String,
  },
  room: {
    type: String,
  },
  roomQuality: {
    type: String,
    enum: ['Excellent', 'Good', 'Average', 'Poor'],
    required: true
  },
  foodQuality: {
    type: String,
    enum: ['Excellent', 'Good', 'Average', 'Poor'],
    required: true
  },
  cleanliness: {
    type: String,
    enum: ['Excellent', 'Good', 'Average', 'Poor'],
    required: true
  },
  overallExperience: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  customerId:{
    type:mongoose.Schema.Types.ObjectId,
    ref:"User"},
    hostelAdminId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User"},
    roomId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Room"}
});

const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports ={Feedback};
