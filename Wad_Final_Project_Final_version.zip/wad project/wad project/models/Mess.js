const mongoose = require("mongoose");

const MessSchema = new mongoose.Schema({
    bookingDate: { type: Date, required: true },
    weekDay: { type: String, required: true, enum: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] },
    packageType: { type: String, required: true, enum: ["Daily", "Weekly", "Monthly"] },
    menu: { type: [String], required: true }, // Array of menu items
    price: { type: Number, required: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Admin who added the menu
}, { timestamps: true });

const Mess = mongoose.model("Mess", MessSchema);
module.exports = Mess;
