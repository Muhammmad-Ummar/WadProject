const mongoose = require('mongoose');
const roomSchema = new  mongoose.Schema({
  roomName: { 
    type: String, 
    required: true,
  },
  roomPrice: { 
    type: Number, 
    required: true 
  },
  roomDescription: { 
    type: String, 
  },
  roomType: {
    type: String,
    required: true,
    enum: ['2', '3'], // adjust or extend as needed
    
  },
  available: { 
    type: Boolean, 
    default: true 
  },
  customersId:[{
    type:mongoose.Schema.Types.ObjectId,
    ref: 'User' 
   }],
   hostelAdminId:{
    type:mongoose.Schema.Types.ObjectId,
    ref: 'User' 
   }
});


module.exports = mongoose.model('Room', roomSchema);
