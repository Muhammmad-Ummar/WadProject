const {verifyUser}=require("../middleware/authenticate")
const{authorize}=require("../middleware/verifyrole")
const {authorizeController,
    addMessDetails, viewMessDetails, bookMessMeal,viewaddmess,viewMessDetail,viewMessAdmin,
    viewMessbooking,viewHostelRegister,viewUsers,viewHostelRooms,createHostelRooms,deleteHostelRooms,viewRoomBooking,handleRoomBooking,updateHostelRooms,removeRoomMemeber,viewRoomFeedback,giveRoomFeedback,viewResidentsFeedback}=require("../controller/userController")
const express=require("express");
const router1=express.Router();
router1.get("/profile",verifyUser,authorizeController);
router1.get("/hostel_register",verifyUser,authorize("hostelAdmin"),viewHostelRegister)
router1.get("/admin_room",verifyUser,authorize("hostelAdmin"),viewHostelRooms)
router1.post("/admin_room",verifyUser,authorize("hostelAdmin"),createHostelRooms)
router1.get("/room_feedback",verifyUser,authorize("customer"),viewRoomFeedback)
router1.post("/submit_feedback",verifyUser,authorize("customer"),giveRoomFeedback)
router1.post("/admin_room/update/:id",verifyUser,authorize("hostelAdmin"),updateHostelRooms)
router1.post("/admin_room/delete/:id",verifyUser,authorize("hostelAdmin"),deleteHostelRooms)
router1.get("/room_data",verifyUser,authorize("customer"),viewRoomBooking)
router1.post("/book_room/:id",verifyUser,authorize("customer"),handleRoomBooking)
router1.post("/delete/:id",verifyUser,authorize("hostelAdmin"),removeRoomMemeber)
router1.get("/view/room_feedback",verifyUser,authorize("hostelAdmin"),viewResidentsFeedback);
router1.get("/admin/users",verifyUser,authorize("hostelAdmin"), viewUsers);
router1.get("/mess_data", verifyUser, authorize("customer"), viewMessbooking);


router1.get("/add_mess", verifyUser,authorize("hostelAdmin"), viewaddmess);
router1.post("/add_mess", verifyUser, authorize("hostelAdmin"), addMessDetails);
router1.get("/view_mess", verifyUser, viewMessDetails);
router1.get("/view_mess1", verifyUser, viewMessDetail);
router1.post("/book_mess/:messId", verifyUser, authorize("customer"), bookMessMeal);
router1.get("/manage-mess", verifyUser,authorize("hostelAdmin"), viewMessAdmin);

module.exports={router1}