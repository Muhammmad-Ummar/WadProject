const jwt=require("jsonwebtoken")
const {User}=require("../models/userModel")
const verifyUser=async(req,res,next)=>{
    if(!req.cookies.data)
        return res.redirect("/login")
    try{
        let encData=req.cookies.data
        let data=jwt.verify(encData,process.env.TOKEN_PASSWORD);
        let user=await User.findOne({_id:data.id});
        if(!user){
           return res.redirect("/login");
        }
        req.data=data;
        next();
    }catch(err){
       console.log(err)
       return res.redirect("/login")
    }
}
module.exports={verifyUser}