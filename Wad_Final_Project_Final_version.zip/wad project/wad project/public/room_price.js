const roomTypeElement = document.getElementById("roomType");
const additionalFeatureElement = document.getElementById("additionalFeature");
const roomPriceElement = document.getElementById("room_price");

const basePrices = {
  "two-seater": 1200,
  "three-seater": 1000
};

const featurePrices = {
  "ac": 200,
  "wifi": 150,
  "balcony": 100,
  "none": 0
};

function updatePrice() {
  const selectedRoom = roomTypeElement.value;
  const selectedFeature = additionalFeatureElement.value;
  
  let totalPrice = basePrices[selectedRoom] + featurePrices[selectedFeature];
  
  roomPriceElement.textContent = `Price: ${totalPrice}`;
}

// Event Listeners to update price when selections change
roomTypeElement.addEventListener("change", updatePrice);
additionalFeatureElement.addEventListener("change", updatePrice);

// Initialize price on page load
updatePrice();