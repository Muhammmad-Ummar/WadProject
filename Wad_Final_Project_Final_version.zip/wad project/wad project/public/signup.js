function validatePassword(password) {
    const letterRegex = /[a-zA-Z]/g; // Matches all alphabetic characters
    const digitRegex = /\d/g;        // Matches all digits
    const letters = password.match(letterRegex); // Find all letters
    const digits = password.match(digitRegex);   // Find all digits

    // Update feedback for letters
    const charCountFeedback = document.getElementById('charCountFeedback');
    if (letters && letters.length >= 4) {
      charCountFeedback.classList.remove('invalid');
      charCountFeedback.classList.add('valid');
    } else {
      charCountFeedback.classList.remove('valid');
      charCountFeedback.classList.add('invalid');
    }

    // Update feedback for digits
    const digitFeedback = document.getElementById('digitFeedback');
    if (digits && digits.length >= 2) {
      digitFeedback.classList.remove('invalid');
      digitFeedback.classList.add('valid');
    } else {
      digitFeedback.classList.remove('valid');
      digitFeedback.classList.add('invalid');
    }

    // Check if password is valid
    return letters && letters.length >= 4 && digits && digits.length >= 2;
  }

  // Event listener for password input
  document.getElementById('password').addEventListener('input', function() {
    validatePassword(this.value);
  });

  // Show/Hide password toggle
  document.getElementById('togglePassword').addEventListener('click', function() {
    const passwordField = document.getElementById('password');
    const type = passwordField.type === 'password' ? 'text' : 'password';
    passwordField.type = type;
    this.textContent = type === 'password' ? 'Show' : 'Hide';
  });

  // Form submit event
  document.getElementById('signupForm').addEventListener('submit', function(event) {
    const password = document.getElementById('password').value;
    if (!validatePassword(password)) {
      event.preventDefault();  // Prevent form submission if password is invalid
    }
  });