document.getElementById('packageSelect').addEventListener('change', function() {
    var selectedPackage = this.value;
    var priceSection = document.getElementById('priceSection');

    if (selectedPackage === 'daily') {
      priceSection.textContent = 'Price: 300 PKR/day';
    } else if (selectedPackage === 'weekly') {
      priceSection.textContent = 'Price: 1590 PKR/week';
    } else if (selectedPackage === 'monthly') {
      priceSection.textContent = 'Price: 4000 PKR/month';
    }
  });